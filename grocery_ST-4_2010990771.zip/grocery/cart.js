let productsincart=0;
function view(){
    let cartbox=document.querySelector(".add-to-cart-box");  
    if(productsincart==0){
        alert("Cart is empty");
    }
    else{
        cartbox.classList.add("display");
    }
    
}

let cross=document.querySelector("#cross");
cross.onclick=()=>{
    let cartbox=document.querySelector(".add-to-cart-box");
    cartbox.classList.remove("display");
}

let addItems=document.querySelectorAll(".add-to-cart");
for(let i=0;i<addItems.length;i++){
     addItems[i].addEventListener('click',addToCart);
}
let quantityFields = document.getElementsByClassName("num");
let removButton=document.getElementsByClassName("remove");
function addToCart(event){
     btn=event.target;
     let parent=btn.parentElement;
     let productItem=parent.children[1].textContent;
     let price=parent.children[3].textContent;
     let tbody=document.getElementsByTagName("tbody")[0];
     tbody.insertAdjacentHTML('beforeend','<tr>'+'<td>'+productItem+'</td>'+'<td>'+'<input type="number" value="1" class="num" min="1" style="border:1px solid black;width:50px;height:30px;"/>'+'</span>'+'</td>'+'<td>'+price+'</td>'+'<td class="total-price">'+price+'</td>'+ '<td><button type="button" class="remove">'+"Remove"+'</button>'+'</tr>');
     productsincart++;
     grandTotal();

  for(let i = 0; i < quantityFields.length; i++){
    quantityFields[i].value = 1;
    quantityFields[i].addEventListener('change', totalCost); 
 }
 for(let i = 0; i < removButton.length; i++){
    removButton[i].value = 1;
    removButton[i].addEventListener('click', removeItem); 
 }
}

function removeItem(event){
    del_btn = event.target;
    del_btn_parent = del_btn.parentElement.parentElement;
    del_btn_parent.remove();
    productsincart--;
    if(productsincart==0)
    {
        let cartbox=document.querySelector(".add-to-cart-box");
        cartbox.classList.remove("display");
        setTimeout(()=>{
            alert("Cart is empty");
        },500);
       
    }
    else{
        grandTotal();
    }
}

function totalCost(event){
    let input=event.target;
    //console.log(input);
    let parents=input.parentElement.parentElement;
    let total=parents.children[2].textContent;
    var pr="";
    for(i=0;i<total.length;i++){
        if(total[i]>='0'&&total[i]<='9')
         pr+=total[i];
    }
    pr=Number.parseInt(pr);
    parents.children[3].innerHTML='Rs'+(event.target.value)*pr;
    grandTotal();
} 
function grandTotal(){
    let total = 0;
    let grand_total = document.getElementsByClassName('grand-total')[0];
    all_total_fields = document.getElementsByClassName('total-price');
    for(let i = 0; i < all_total_fields.length; i++){
        all_prices = all_total_fields[i].textContent;
        //console.log(all_prices);
        pr="";
        for(j=0;j<all_prices.length;j++){
        if(all_prices[j]>='0'&&all_prices[j]<='9')
            pr+=all_prices[j];
           // console.log(pr);
        }
        total+=Number.parseInt(pr);
    }
    grand_total.innerText = 'Rs'+total;
   
    console.log(total);
}
